import Navbar from './components/navbar/navbar.js';
import Home from './components/home/home.js';
import './App.css';

function App() {
  return (
    <>
      <Navbar />
      <Home />
    </>
  );
}

export default App;
